let recipe1 = {
  recipeId: 1,
  bookmark: false,
  category: "westernFood",
  material: "빵, 고기",
  dishName: "햄버거",
  recipeText: "고기 구워",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/o5lE3DhCB9NCYp_AzyPszyOblhB7JDtoWaFiV6H3NNUpKxiwyRaG0fn_XEWzc43fv5uI2cV4EDOrMth9tsbslA.webp",
};
let recipe2 = {
  recipeId: 2,
  bookmark: true,
  category: "westernFood",
  material: "토마토 소스, 파스타 면",
  dishName: "파스타",
  recipeText: "면 끌여",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/_Y1KfAkYUNsL3o_nt_ok1BVfJJwEEO8xiVHMzsQO7fWvvtFwBAWWavROORH3dGOGtBry2kP77hhOnHNPk4Xz5Q.webp",
};

let recipe3 = {
  recipeId: 3,
  bookmark: false,
  category: "westernFood",
  material: "밀가루, 치즈",
  dishName: "피자",
  recipeText: "야.. 이건 시켜먹자",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/umI-heVYVS9miQNqXM13FRUOHHL4l1nzsZgN9XRLFG7nI_7Dyf-Myr6HmiWf9Qd7SAZQz3WYSQHPXXtGAwLTag.webp",
};

let recipe4 = {
  recipeId: 4,
  bookmark: false,
  category: "westernFood",
  material: "소고기",
  dishName: "스태이크",
  recipeText: "구워~",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/8HjXHmgc7e_5KZVmId552aTeMjiaDhyamd_XO9WUzD0AIG9jK4c6ULrJrec8MZMFiFm8tNO6wbr6sNGJkzbFJw.webp",
};

let recipe5 = {
  recipeId: 5,
  bookmark: false,
  category: "chineseFood",
  material: "홍합, 오징어",
  dishName: "짬뽕",
  recipeText: "보글보글",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/upNZ7cYsFsAfU0KcguO6OHMK68xC-Bj8EXxdCti61Jhjx10UCBgdK5bZCEx41-aAWcjWZ5JMKFUSaUGLC1tqWg.webp",
};

let recipe6 = {
  recipeId: 6,
  bookmark: false,
  category: "chineseFood",
  material: "면, 짜장",
  dishName: "짜장면",
  recipeText: "보글보글",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/j2AxLP9AtrcJebh4DVfGxowfXwI3a95dG_YZb_Ktczc6Ca7ACyd_NJL3YHQMw8SABGTQiJDwSpySOSSBLZVEZw.webp",
};

let recipe7 = {
  recipeId: 7,
  bookmark: false,
  category: "japaneseFood",
  material: "돼지고기, 빵가루",
  dishName: "돈가스",
  recipeText: "튀겨",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/aN7eMJzy4XAy1yqpL3kHb41MBsSdfPjt1ZqMfDXYk6J3-je6M8dNVOMldpbxhZ-IlO9IfHXMzpZc1tVvat5IjQ.webp",
};
let recipe8 = {
  recipeId: 8,
  bookmark: false,
  category: "japaneseFood",
  material: "생선, 밥",
  dishName: "초밥",
  recipeText: "낚시 부터..",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/x8ahJqwvEyKkM0zVH-QJVFEVvFDrKnNfhQpvzPFM7DrOz5U0AsV4cgDe2R9xxfoe5Dt_EupPfgrP3-HlO2BXQA.webp",
};

let recipe9 = {
  recipeId: 9,
  bookmark: true,
  category: "japaneseFood",
  material: "메밀, 무",
  dishName: "메밀소바",
  recipeText: "보글보글",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/q90KM4HtKZ_but8KDP06TQoj7pNzrdxgBnXoWFCr-L7rW2z4SLm6Z-Xt06M5UHSSqGRy4OxpAUG5BfqGxzVn3w.webp",
};

let recipe10 = {
  recipeId: 10,
  bookmark: false,
  category: "koreanFood",
  material: "김치, 돼지고기",
  dishName: "김치찌개",
  recipeText: "보글보글",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/8drgvI-cQLUfJDC00zbl2ZolK4W3o4ZkVSpR-zM5FZk_QzT58vYnx_7ohk0qwGYYiSLPiZgwccyIEFUtYKDjUQ.webp",
};

let recipe11 = {
  recipeId: 11,
  bookmark: true,
  category: "koreanFood",
  material: "된장, 야채",
  dishName: "된장찌개",
  recipeText: "끓여",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/YO50_C3aCdAuE-lGan7O4jySABF2vYoC2zlzo7BNY0fFYvE_QjRE9hhz8Ni7YT56SISxSO2iacP0eTsO8DbdXQ.webp",
};
let recipe12 = {
  recipeId: 12,
  bookmark: false,
  category: "koreanFood",
  material: "소고기, 야채",
  dishName: "불고기",
  recipeText: "볶아",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/1fMv9BlDolXCcO2TlBW0zuV14FbmYAQf71zBGjY8RvtoP3x-zDBo0jiQxy4gdQ8ipfOqa9NNgGc5AOPVfRHlzQ.webp",
};

let recipe13 = {
  recipeId: 13,
  bookmark: false,
  category: "koreanFood",
  material: "돼지고기, 야채",
  dishName: "제육볶음",
  recipeText: "볶아",
  writeDate: "2024-2-14",
  dishImg:
    "https://i.namu.wiki/i/hdmtB9UgCj1Y8ojfYf-TOjWPRnhjYHA9wsWH-jofsvvabZBT5aDCbNXrPieh2yxS9IyZ0ERMO9ZObRJKa4GIiw.webp",
};

let recipeArr = [
  recipe1,
  recipe2,
  recipe3,
  recipe4,
  recipe5,
  recipe6,
  recipe7,
  recipe8,
  recipe9,
  recipe10,
  recipe11,
  recipe12,
  recipe13,
];

// 슬라이드 위에 북마크 체크를 수정하면서 북마크에 따라 슬라이드 내용이 변화하는 것 확인.

const carousel1 = document.getElementById("carousel1");
const carousel2 = document.getElementById("carousel2");
const carousel3 = document.getElementById("carousel3");

let bookmarkArr = recipeArr.filter((e) => e.bookmark); // 북마크가 true 인 recipeArr의 값들로 이루어진 배열 생성

window.addEventListener("DOMContentLoaded", function showCarousel() {
  console.log(bookmarkArr);
  // 슬라이드 //////////////////////////////////////////////////
  carousel1.style.backgroundImage = `url(${bookmarkArr[0].dishImg})`;
  carousel2.style.backgroundImage = `url(${bookmarkArr[1].dishImg})`;
  carousel3.style.backgroundImage = `url(${bookmarkArr[2].dishImg})`;
});

carousel1.addEventListener("click", carousel1Click);

function carousel1Click() {
  console.log("1클릭");
  console.log(bookmarkArr[0].category);
  window.location.href = `http://localhost:8080/myapp/board/${bookmarkArr[0].category}.do`;
  window.localStorage.setItem("id", bookmarkArr[0].recipeId);
}

carousel2.addEventListener("click", carousel2Click);

function carousel2Click() {
  console.log("2클릭");
  console.log(bookmarkArr[1].category);
  window.location.href = `http://localhost:8080/myapp/board/${bookmarkArr[1].category}.do`;
  window.localStorage.setItem("id", bookmarkArr[1].recipeId);
}

carousel3.addEventListener("click", carousel3Click);

function carousel3Click() {
  console.log("3클릭");
  console.log(bookmarkArr[2].category);
  window.location.href = `http://localhost:8080/myapp/board/${bookmarkArr[2].category}.do`;
  window.localStorage.setItem("id", bookmarkArr[2].recipeId);
}
